# @verentis/sdk

Verentis SDK — file system access, app framework, and developer tools for building Verentis applications.

## Installation

```bash
npm install @verentis/sdk
```

## Quick Start

### Hosted header actions (SDK 0.2)

Applications register buttons after `await client.whenReady()`. The workspace owns their
presentation; handlers execute inside the application with its existing delegated token.

```ts
const save = client.bridge!.registerAction({
  id: 'document.save',
  label: 'Save',
  icon: 'lucide:save',
  variant: 'default',
  scopes: ['node.file.read', 'node.node.create', 'node.node.update', 'node.journal.create'],
  enabled: false,
}, async () => {
  await persistDocument()
})

// Pass the complete descriptor when document state changes.
save.update({ id: 'document.save', label: 'Save', scopes: [
  'node.file.read', 'node.node.create', 'node.node.update', 'node.journal.create',
], enabled: true })
save.dispose()
```

Use stable app-local IDs, up to 16 actions, Lucide icon identifiers, and explicit `scopes`
(`[]` for client-only operations). `enabled`, `visible`, `busy`, and `disabledReason` communicate
state without serializing handlers. The host checks required scopes against the delegated grant;
registration never expands permissions. Throw on failure so the host can display it.

For clipboard actions, set `kind: 'clipboard'` and return `{ clipboardText: source }`. The host starts
the clipboard write in the user's click gesture while awaiting the text, preserving browser
user-activation requirements. For operations that navigate after completion, return
`{ navigate: { path: '/applications', newTab: false } }` instead of navigating before the result.

The protocol uses session-bound `verentis:actions:set`, `verentis:action:invoke`, and
`verentis:action:result` messages. Reload/navigation disposes pending work; an unanswered invocation
times out as **outcome unknown**, never an automatic retry. App handlers must not report successful
completion before their mutation finishes.

Migrated actions are hosted only: there is no legacy-host or standalone-toolbar fallback.
Fullscreen apps can hide the host header only when they register no actions. Keep specialized
controls (zoom, editing modes, contextual forms) within the app.

Release the 0.2 SDK before deploying apps that require `^0.2.0`, together with the matching host.
Local sibling-repository development can link the built SDK; published applications must resolve
the released SDK from npm.

### Standalone mode (local development)

```ts
import { createVerentisClient } from '@verentis/sdk'

const client = createVerentisClient({
  apiUrl: 'https://api.verentis.com',
  auth: { apiKey: 'vrt_abc123_...' },
  workspaceId: 'workspace-uuid',
})

const file = await client.files.get('/documents/report.json')
```

### Running executions

Run a file in the virtual file system — the platform resolves the right engine from the file type
(e.g. a `.py` file runs on the Python engine), waits for it, and returns the result:

```ts
import { createVerentisClient } from '@verentis/sdk'

const client = createVerentisClient({
  apiUrl: 'https://api.verentis.com',
  auth: { token: '...' },
  workspaceId: 'workspace-uuid',
})

// Run a script and await the result (request-response engines return immediately).
const execution = await client.executions.runAndWait('/scripts/report.py', {
  arguments: ['--verbose'],
  parameters: { month: '2025-01' },
})

console.log(execution.status)            // 'Completed'
console.log(execution.result?.stdout)    // engine stdout

// Or trigger and inspect explicitly.
const started = await client.executions.run('/scripts/report.py')
const current = await client.executions.get(started.id)
const logs = await client.executions.logs(started.id)
await client.executions.cancel(started.id)
```


### iframe mode (inside Verentis workspace)

```ts
import { createVerentisClient } from '@verentis/sdk'

const client = createVerentisClient()
await client.whenReady()

const { surface, workspace } = client.context

if (surface === 'file') {
  const content = await client.files.readContent(client.context.file.path)
} else {
  // A manifest-enabled spec.launch surface has workspace context but no file.
  renderWorkspaceHome(workspace)
}
```

`spec.launch` is still iframe mode: the host sends `surface: 'workspace'`, the selected
`entryPoint`, and no `file`. This is distinct from SDK standalone mode, where you pass `apiUrl`,
credentials and `workspaceId` yourself.

## API Overview

| Export | Description |
| --- | --- |
| `createVerentisClient(options?)` | Factory function — creates a configured `VerentisClient` |
| `VerentisClient` | Main client class with `files`, `executions`, `settings`, `context`, and `bridge` |
| `FilesModule` | File operations — get, read, write, move, delete, archive |
| `ExecutionsModule` | Execution operations — run, execute, get, logs, cancel, wait |
| `SettingsModule` | Workspace settings — list, get, getValue, set, reset, namespaced |
| `ContextModule` | Workspace and launch-surface context (populated after init) |
| `Bridge` | PostMessage transport for iframe ↔ host communication |
| `HttpTransport` | HTTP client for API requests |
| `ApiKeyAuth` | Auth strategy using API keys |
| `TokenAuth` | Auth strategy using bearer tokens |
| `BridgeAuth` | Auth strategy that receives tokens via the bridge |
| `matchMimeType` / `findBestMatch` | MIME type matching utilities |

### Workspace settings

Apps whose manifest declares `spec.settings[]` get workspace setting definitions auto-registered
(namespaced `{manifest-name}.{key}`). Read them with the settings module — the app token needs the
`fabric.setting.read` / `fabric.setting.read-all` permissions from `spec.permissions`:

```ts
const settings = client.settings.namespaced('my-app')
const region = await settings.getValue<string>('region', 'eu')
```

Secret values never reach the browser: secrets read as `value: null` with `hasValue` reporting
whether one is configured. Engines receive secrets server-side at execution time instead.

See [docs/api-reference.md](docs/api-reference.md) for full API documentation.

## Development

```bash
# Install dependencies
npm install

# Build the package
npm run build

# Run tests
npm test

# Watch mode (rebuild on changes)
npm run dev

# Type checking
npm run typecheck
```

## Versioning

This project uses [GitVersion](https://gitversion.net/) for automatic semantic versioning:

- Commits to `main` produce clean versions (e.g., `0.1.1`, `0.1.2`)
- Feature branches produce pre-release versions (e.g., `0.2.0-my-feature.1`)
- Use commit message tags to control version bumps:
  - `+semver: breaking` or `+semver: major` — major bump
  - `+semver: feature` or `+semver: minor` — minor bump
  - `+semver: fix` or `+semver: patch` — patch bump (default)
  - `+semver: none` or `+semver: skip` — no bump

## License

UNLICENSED — proprietary software.
